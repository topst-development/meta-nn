#include <stdio.h>
#include <stdlib.h>
#include "global.h"

int main()

{
    // Open Scaler Device
    int scalerFd = videoScaleOpen("/dev/scaler1");
    // Open Display Device
	int overlayFd = videoOutputOpen("/dev/overlay");
    // Open and Initialize Camera Device
    videoInputOpen("/dev/video0");
	videoInputInit();
	videoInputStart();

    // Camera Pysical address
    uint64_t frameBuf;
    // Camera Virtual address
	uint8_t *frameBufVir;

    int frameCnt = 0;
	while(1)
    {
        // Get Camera Frame
        videoInputPop(&frameBuf, &frameBufVir);
        if(frameCnt % 2 == 0) // For duble-buffering
        {
            // Resize Frame (1920x1080, RGBA8888 -> 1920x720, RGB888)
            // videoScaleResize(scalerFd, frameBuf, INPUT_IMAGE_WIDTH, INPUT_IMAGE_HEIGHT, OUTPUT_IMAGE_1, LCD_WIDTH, LCD_HEIGHT);
            // Wait Scaler Interrupt
            videoScalePoll(scalerFd);
            // Draw buffer on LCD
            videoOutputPush(overlayFd, frameBuf);
        }
        else
        {
            // videoScaleResize(scalerFd, frameBuf, INPUT_IMAGE_WIDTH, INPUT_IMAGE_HEIGHT, OUTPUT_IMAGE_2, LCD_WIDTH, LCD_HEIGHT);
            // videoScalePoll(scalerFd);
            videoOutputPush(overlayFd, frameBuf);
        }

        frameCnt++;
        printf("%d\n", frameCnt);
        // FILE *fp = fopen("ir_cam_dump.bin", "wb");
        // fwrite(frameBufVir, 1, INPUT_IMAGE_SIZE, fp);
        // fclose(fp);
        // if(frameCnt > 10)
        // {
        //     break;
        // }
        videoInputPush(&frameBuf, &frameBufVir);
    }

    // Stop and Close Camera
	videoInputStop();
    videoInputClose();
    
    // Deinit VIOC Drivers
	close(scalerFd);
	close(overlayFd);
    
}