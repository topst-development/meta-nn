#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <linux/videodev2.h>
#include <pthread.h>
#include "global.h"

#define MAX_VIDEO_BUFFER 3

static pthread_t videoInputThread;
static pthread_mutex_t videoInputMutex = PTHREAD_MUTEX_INITIALIZER;

typedef struct video_buffer
{
	struct v4l2_buffer	buf;
	struct v4l2_plane	plane[3];
	int isUsed;
	int isOwned;
} video_buffer_t;

static video_buffer_t videoBuffer[MAX_VIDEO_BUFFER];
static uint8_t *cameraVaddr[5];
static uint64_t cameraPaddr[5];

static int cameraFd = -1;
static int8_t latestBufIdx = -1;
static int8_t usedBufIdx = -1;
static uint8_t ownedBufCnt = 0;
static uint8_t videoInputStartFlag = 0;

int videoInputOpen(const char *cameraPath)
{
    cameraFd = open(cameraPath, O_RDWR);
	if(cameraFd < 0)
	{
		printf("camera open error! : %s\n", cameraPath);
		exit(1);
	}
	else
	{
		return 1;
	}
}

void videoInputClose()
{
    close(cameraFd);
	cameraFd = -1;
}

void videoInputInit()
{
	struct v4l2_capability cap;
	int ret;

	// Camera Init Start
	if(cameraFd < 0)
    {
        printf("Camera Device does not opened!!\n");
        exit(1);
    }
	
	struct v4l2_capability capa;
	if(ioctl(cameraFd, VIDIOC_QUERYCAP, &capa) < 0)
	{
		printf("VIDIOC_QUERYCAP\n");
		exit(1);
	}

	if(!(capa.capabilities & V4L2_CAP_VIDEO_CAPTURE_MPLANE))
	{
		printf("The device does not handle multi-planar video capture.\n");
		exit(1);
	}

    struct v4l2_format format;
	format.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	format.fmt.pix_mp.width = INPUT_IMAGE_WIDTH;
	format.fmt.pix_mp.height = INPUT_IMAGE_HEIGHT;
	format.fmt.pix_mp.pixelformat = V4L2_PIX_FMT_RGB32;
	format.fmt.pix_mp.field = 0;
	format.fmt.pix_mp.num_planes = 1;
	format.fmt.pix_mp.plane_fmt[0].sizeimage = INPUT_IMAGE_SIZE;
	
	if(ioctl(cameraFd, VIDIOC_S_FMT, &format) < 0)
	{
		printf("VIDIOC_S_FMT\n");
		exit(1);
	}

	struct v4l2_requestbuffers bufrequest;
	bufrequest.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
	bufrequest.memory = V4L2_MEMORY_MMAP;
	bufrequest.count = 5;

	if(ioctl(cameraFd, VIDIOC_REQBUFS, &bufrequest) < 0)
	{
		printf("VIDIOC_REQBUFS\n");
		exit(1);
	}

	struct v4l2_buffer bufferinfo;
	struct v4l2_plane planes[3];
	int buffer_index;
	for(buffer_index = 0; buffer_index < bufrequest.count; buffer_index++)
	{
		memset(&bufferinfo, 0, sizeof(bufferinfo));
		memset(&planes, 0,  sizeof(planes));
		bufferinfo.index = buffer_index;
		bufferinfo.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
		bufferinfo.memory = V4L2_MEMORY_MMAP;
		bufferinfo.m.planes = planes;
		bufferinfo.length = 1;
		if(ioctl(cameraFd, VIDIOC_QUERYBUF, &bufferinfo) < 0)
		{
			printf("VIDIOC_QUERYBUF\n");
			exit(1);
		}
		cameraPaddr[buffer_index] = (uint64_t)planes[0].reserved[0];
		cameraVaddr[buffer_index] = mmap(NULL, planes[0].length, PROT_READ|PROT_WRITE, MAP_SHARED, cameraFd, planes[0].m.mem_offset);
		printf("V4L2 buffer initialized idx:%d, 0x%x\n", buffer_index, cameraPaddr[buffer_index]);
		if(cameraVaddr[buffer_index] == MAP_FAILED)
		{
			printf("mmap fail\n");
			exit(1);
		}
		if(ioctl(cameraFd, VIDIOC_QBUF, &bufferinfo) < 0)
		{
			printf("VIDIOC_QBUF error\n");
			exit(1);
		}
		memset(cameraVaddr[buffer_index], 0, planes[0].length);
	}
	
	// Activate streaming
	int type = bufferinfo.type;
	if(ioctl(cameraFd, VIDIOC_STREAMON, &type) < 0)
	{
		printf("VIDIOC_STREAMON\n");
		exit(1);
	}

	int buffer_idx;
	for (buffer_idx = 0; buffer_idx < MAX_VIDEO_BUFFER; buffer_idx++)
	{
		(void)memset((void *)&videoBuffer[buffer_idx].buf, 0, sizeof(videoBuffer[buffer_idx].buf));
		(void)memset((void *)videoBuffer[buffer_idx].plane, 0, sizeof(videoBuffer[buffer_idx].plane));
		videoBuffer[buffer_idx].buf.type		= V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
		videoBuffer[buffer_idx].buf.memory		= V4L2_MEMORY_MMAP;
		videoBuffer[buffer_idx].buf.m.planes	= videoBuffer[buffer_idx].plane;
		videoBuffer[buffer_idx].buf.length		= 1;
	}
}


static void videoInputRequest(struct v4l2_buffer *bufferinfo)
{
	videoPoll(cameraFd);
    if(ioctl(cameraFd, VIDIOC_DQBUF, bufferinfo) < 0)
    {
        printf("VIDIOC_DQBUF error\n");
        exit(1);
    }
}


static void videoInputRelease(struct v4l2_buffer *bufferinfo)
{
    if(ioctl(cameraFd, VIDIOC_QBUF, bufferinfo) < 0)
    {
        printf("VIDIOC_QBUF error\n");
        exit(1);
    }
}


void videoInputPop(uint64_t *paddr, uint8_t **vaddr)
{
	// If the buffer currently in use is the latest buffer, wait 100us
	while(usedBufIdx == latestBufIdx)
	{
		usleep(100);
	}
pthread_mutex_lock(&videoInputMutex);
	usedBufIdx = latestBufIdx;
	*paddr = cameraPaddr[videoBuffer[latestBufIdx].buf.index];
	*vaddr = cameraVaddr[videoBuffer[latestBufIdx].buf.index];
	videoBuffer[latestBufIdx].isUsed = 1;
pthread_mutex_unlock(&videoInputMutex);
}


void videoInputPush(uint64_t *paddr, uint8_t **vaddr)
{
	int idx = 0;
	for(idx = 0; idx < MAX_VIDEO_BUFFER; idx++)
	{
		if(videoBuffer[idx].isUsed && *paddr == cameraPaddr[videoBuffer[idx].buf.index])
		{
			videoBuffer[idx].isUsed = 0;
		}
	}
}


int videoPoll()
{
    struct pollfd pfd;
    int ret = 0;

    /* set pfd */
    (void)memset((void *)&pfd, 0, sizeof(pfd));
    pfd.fd      = cameraFd;
    pfd.events  = POLLIN;

    ret = poll(&pfd, 1, 50);
    if (ret > 0)
    { 
        ret = (int)pfd.revents;
    }
    return ret;
}


void *videoInputThreadFunction(void *data)
{
	int bufIdx = 0;
	while(videoInputStartFlag)
	{
		if(ownedBufCnt < MAX_VIDEO_BUFFER && !videoBuffer[bufIdx].isOwned && !videoBuffer[bufIdx].isUsed)
		{
			videoInputRequest(&videoBuffer[bufIdx].buf);
			videoBuffer[bufIdx].isOwned = 1;
pthread_mutex_lock(&videoInputMutex);
			latestBufIdx = bufIdx;
pthread_mutex_unlock(&videoInputMutex);
			ownedBufCnt++;
		}
		bufIdx++;
		bufIdx%=MAX_VIDEO_BUFFER;

		int i;
		for(i=0;i<MAX_VIDEO_BUFFER; i++)
		{
			if(ownedBufCnt == MAX_VIDEO_BUFFER && videoBuffer[i].isOwned && !videoBuffer[i].isUsed && latestBufIdx != i) 
			{
				videoInputRelease(&videoBuffer[i].buf);
				videoBuffer[i].isOwned = 0;
				ownedBufCnt--;
			}
		}
	}
}


void videoInputStart()
{
	videoInputStartFlag = 1;
	pthread_create(&videoInputThread, NULL, videoInputThreadFunction, (void *)NULL);
}


void videoInputStop()
{
	videoInputStartFlag = 0;
	pthread_join(videoInputThread, NULL);
}