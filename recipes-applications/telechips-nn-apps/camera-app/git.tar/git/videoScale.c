#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "tcc_scaler_ioctrl.h"
#include "global.h"

int videoScaleOpen(const char *scalerPath)
{
    int scalerFd;
    scalerFd = open(scalerPath, O_RDWR | O_NDELAY);
    return scalerFd;
}


void videoScaleClose(const int scalerFd)
{
    close(scalerFd);
}

void videoScaleResize(const int scalerFd, unsigned long srcPmap, int srcW, int srcH, unsigned long desPmap, int desW, int desH)
{
	struct SCALER_TYPE scaler_info;
  
	/* memset 0 scaler info structure */
	memset(&scaler_info, 0, sizeof(struct SCALER_TYPE));
  
	/* set scaler response type : interrupt */
	scaler_info.responsetype = SCALER_INTERRUPT; // SCALER_POLLING or SCALER_INTERRUPT
  
	/* source setting */
	scaler_info.src_Yaddr = srcPmap;
	scaler_info.src_Uaddr = srcPmap;
	scaler_info.src_Vaddr = srcPmap;
	scaler_info.src_winLeft = 0;
	scaler_info.src_winTop = 0;
	scaler_info.src_winRight = srcW;
	scaler_info.src_winBottom = srcH;
	scaler_info.src_ImgWidth = srcW;
	scaler_info.src_ImgHeight = srcH;
	scaler_info.src_fmt = SCALER_ARGB8888;
  
	/* destination setting */
	scaler_info.dest_Yaddr = desPmap;
	scaler_info.dest_Uaddr = desPmap;
	scaler_info.dest_Vaddr = desPmap;
	scaler_info.dest_winLeft = 0;
	scaler_info.dest_winTop = 0;
	scaler_info.dest_winRight = desW;
	scaler_info.dest_winBottom = desH;
	scaler_info.dest_ImgWidth = desW;
	scaler_info.dest_ImgHeight = desH;
	scaler_info.dest_fmt = SCALER_RGB888;
  
	// printf("Frame Resize : input[%8lx,%dx%d] -> output[%8lx,%dx%d]\n", srcPmap, srcW, srcH, desPmap, desW, desH);
	/* executing scaler */
	if ( ioctl(scalerFd, TCC_SCALER_IOCTRL, (unsigned long)&scaler_info) < 0 )
	{
		printf("scaler ioctl() error!!\n");
	}
}

void videoScaleCrop(int scalerFd, unsigned long srcPmap, int winXMin, int winYMin, int winXMax, int winYMax, int width, int height, int srcC, unsigned long desPmap, int desW, int desH, int desC)
{
	struct SCALER_TYPE scaler_info;
  
	/* memset 0 scaler info structure */
	memset(&scaler_info, 0, sizeof(struct SCALER_TYPE));
  
	/* set scaler response type : interrupt */
	scaler_info.responsetype = SCALER_INTERRUPT;//SCALER_POLLING or SCALER_INTERRUPT
  
	/* source setting */
	scaler_info.src_Yaddr = srcPmap;
	scaler_info.src_Uaddr = srcPmap;
	scaler_info.src_Vaddr = srcPmap;
	scaler_info.src_winLeft = winXMin;
	scaler_info.src_winTop = winYMin;
	scaler_info.src_winRight = winXMax;
	scaler_info.src_winBottom = winYMax;
	scaler_info.src_ImgWidth = width;
	scaler_info.src_ImgHeight = height;
	scaler_info.src_fmt = srcC;
  
	/* destination setting */
	scaler_info.dest_Yaddr = desPmap;
	scaler_info.dest_Uaddr = desPmap;
	scaler_info.dest_Vaddr = desPmap;
	scaler_info.dest_winLeft = 0;
	scaler_info.dest_winTop = 0;
	scaler_info.dest_winRight = desW;
	scaler_info.dest_winBottom = desH;
	scaler_info.dest_ImgWidth = desW;
	scaler_info.dest_ImgHeight = desH;
	scaler_info.dest_fmt = desC;
  
	// printf("input[%8lx,(%d, %d), (%d, %d)] -> output[%8lx,%dx%d]\n", srcPmap, winXMin, winYMin, winXMax, winYMax, desPmap, desW, desH);
	/* executing scaler */
	if ( ioctl(scalerFd, TCC_SCALER_IOCTRL, (unsigned long)&scaler_info) < 0 )
	{
		printf("scaler ioctl() error!!\n");
	}
}


int videoScalePoll(const int fd)
{
	int ret = 0;
	struct pollfd poll_event[1];
 
	if (fd < 0)
	{
		return -1;
	}
 
	memset(poll_event, 0, sizeof(poll_event));
	poll_event[0].fd = fd;
	poll_event[0].events = POLLIN;
	ret = poll((struct pollfd *)poll_event, 1, 4000);

	if (ret < 0)
	{
		printf("poll() error %d\n", __LINE__);
		return -1;
	}
	else if (ret == 0)
	{
		printf("poll() Timeout %d\n", __LINE__);
		return -1;
	}
	else if (ret > 0)
	{
		if (poll_event[0].revents & POLLERR)
		{
			printf("poll() error %d\n", __LINE__);
			return -1;
		}
	}

	return 0;
}