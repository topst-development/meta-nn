#include <sys/ioctl.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "tcc_overlay_ioctl.h"
#include "global.h"

int videoOutputOpen(const char *overlayPath)
{
	int overlayFd;
	overlayFd = open(overlayPath, O_RDWR);
	if(overlayFd < 0)
	{
		printf("overlay open error! : %s\n", overlayPath);
		exit(0);
	}
	return overlayFd;
}


void videoOutputClose(int overlayFd)
{
    close(overlayFd);
}


void videoOutputInit()
{

}

void videoOutputDeinit()
{

}


void videoOutputPush(int overlayFd, unsigned long baseAddr)
{
	overlay_video_buffer_t overBuffCfg;
	overBuffCfg.cfg.sx = 0x0;
	overBuffCfg.cfg.sy = 0x0;
	overBuffCfg.cfg.width = LCD_WIDTH;
	overBuffCfg.cfg.height = LCD_HEIGHT;
	overBuffCfg.cfg.format = 14; // YUYV:26, RGB888:14, ARGB888:12
	overBuffCfg.cfg.transform = 0;      // N/A, set 0

	overBuffCfg.addr = baseAddr;
	overBuffCfg.addr1 = 0;
	overBuffCfg.addr2 = 0;
	overBuffCfg.afbc_dec_num = 0;
	overBuffCfg.afbc_dec_need = 0;
	ioctl(overlayFd, OVERLAY_PUSH_VIDEO_BUFFER, (unsigned long)&overBuffCfg);
}

