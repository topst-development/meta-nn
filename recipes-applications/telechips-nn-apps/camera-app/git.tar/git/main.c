#include <stdio.h>
#include <stdlib.h>
#include "global.h"

int main()

{
    // Open Scaler Device
    int scalerFd = videoScaleOpen("/dev/scaler1");
    // Open Display Device
	int overlayFd = videoOutputOpen("/dev/overlay");
    // Open and Initialize Camera Device
    videoInputOpen("/dev/video0");
	videoInputInit();
	videoInputStart();

    // Camera Pysical address
    uint64_t frameBuf;
    // Camera Virtual address
	uint8_t *frameBufVir;

    int frameCnt = 0;
	while(1)
    {
        // Get Camera Frame
        videoInputPop(&frameBuf, &frameBufVir);
        if(frameCnt % 2 == 0) // For duble-buffering
        {
            // Resize Frame (1920x1080, RGBA8888 -> 1920x720, RGB888)
            videoScaleResize(scalerFd, frameBuf, INPUT_IMAGE_WIDTH, INPUT_IMAGE_HEIGHT, OUTPUT_IMAGE_1, LCD_WIDTH, LCD_HEIGHT);
            // Wait Scaler Interrupt
            videoScalePoll(scalerFd);
            // Draw buffer on LCD
            videoOutputPush(overlayFd, OUTPUT_IMAGE_1);
        }
        else
        {
            videoScaleResize(scalerFd, frameBuf, INPUT_IMAGE_WIDTH, INPUT_IMAGE_HEIGHT, OUTPUT_IMAGE_2, LCD_WIDTH, LCD_HEIGHT);
            videoScalePoll(scalerFd);
            videoOutputPush(overlayFd, OUTPUT_IMAGE_2);
        }
        videoInputPush(&frameBuf, &frameBufVir);
        frameCnt++;
    }

    // Stop and Close Camera
	videoInputStop();
    videoInputClose();
    
    // Deinit VIOC Drivers
	close(scalerFd);
	close(overlayFd);
    
}